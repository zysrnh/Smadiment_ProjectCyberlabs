<footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
        <div class="row">
            <div class="col my-1">
                <p class="m-0">SMADIMENT &copy; {{ date('Y') }} — Social Media Analytics Platform</p>
            </div>
            <div class="col-md-auto my-1">
                <ul class="list-inline footer-link mb-0">
                    <li class="list-inline-item"><a href="{{ route('mk.dashboard') }}">Dashboard</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>